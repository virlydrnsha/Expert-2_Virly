import FavoriteRestaurant from '../../data/favorite-restaurant';
import { createRestaurantItemTemplate } from '../templates/template-restaurant';

const Favorite = {
  async render() {
    return `
        <a href="#content" class="skip-link">Skip to Content</a>    
        <section id="content" class="content">
            <h2>Favorite Restaurant List</h2>
            <div id="list" class="listresto">
            </div>
        </section>
      `;
  },

  async afterRender() {
    const restaurants = await FavoriteRestaurant.getAllRestaurants();
    const restaurantsContainer = document.querySelector('#list');
    restaurants.forEach((restaurant) => {
      restaurantsContainer.innerHTML += createRestaurantItemTemplate(restaurant);
    });
  },
};
export default Favorite;
