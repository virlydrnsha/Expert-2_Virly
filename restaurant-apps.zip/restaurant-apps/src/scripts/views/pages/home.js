import RestaurantDbSource from '../../data/restaurant-source';
import { createRestaurantItemTemplate } from '../templates/template-restaurant';

const Home = {
  async render() {
    return `
    <div class="hero">
    <div class="heroinner">
      <p class="herotitle">Let's Explore Indonesian Delicious Food Recommendations✨</p>
    </div>
  </div>

  <section class="content">
    <h2 class="list-title">-------List Restaurant-------</h2>
    <div id="list" class="list-restoran">
    </section>
      `;
  },

  async afterRender() {
    const restaurants = await RestaurantDbSource.restaurants();
    const restaurantsContainer = document.querySelector('#list');
    restaurants.forEach((restaurant) => {
      restaurantsContainer.innerHTML += createRestaurantItemTemplate(restaurant);
    });
  },
};

export default Home;
