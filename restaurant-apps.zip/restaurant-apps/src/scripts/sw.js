import 'regenerator-runtime';
import CacheHelper from './utils/cache-helper';

// Daftar asset yang akan dicaching
const assetsToCache = [
  './',
  './icons/icon-72x72.jpg',
  './icons/icon-96x96.jpg',
  './icons/icon-128x128.jpg',
  './icons/icon-144x144.jpg',
  './icons/icon-152x152.jpg',
  './icons/icon-192x192.jpg',
  './icons/icon-384x384.jpg',
  './icons/icon-512x512.jpg',
  './icons/icon.png',
  './images/heros/hero-image_4.jpg',
  './index.html',
  './favicon.jpg',
  './app.bundle.js',
  './app.webmanifest',
  './sw.bundle.js',
];

self.addEventListener('install', (event) => {
  event.waitUntil(CacheHelper.cachingAppShell([...assetsToCache]));
});

self.addEventListener('activate', (event) => {
  event.waitUntil(CacheHelper.deleteOldCache());
});

self.addEventListener('fetch', (event) => {
  event.respondWith(CacheHelper.revalidateCache(event.request));
});
